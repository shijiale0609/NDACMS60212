#if !defined(__WRAPPER__)
#define __WRAPPER__

int cuda_kernel_wrapper(float*, int, int);

#endif 
