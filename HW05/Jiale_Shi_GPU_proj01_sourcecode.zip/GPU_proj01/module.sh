module load cuda/10.0
